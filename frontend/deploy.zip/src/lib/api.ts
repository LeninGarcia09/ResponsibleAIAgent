// API client for communicating with the backend
const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:7071/api'

export interface AIReviewSubmission {
  submitter_email?: string
  submitter_name?: string
  project_name: string
  project_description?: string
  ai_capabilities?: string[]
  data_sources?: string[]
  user_impact?: string
  deployment_stage?: string
  fairness_assessment?: string
  bias_testing?: string
  transparency_measures?: string
  privacy_controls?: string
  accountability_framework?: string
  data_encryption_method?: string
  access_control_mechanism?: string
  compliance_certifications?: string[]
  additional_context?: Record<string, any>
}

export interface Recommendation {
  principle: string
  priority: string
  recommendations: string[]
  tools?: Array<{
    name: string
    url: string
    description: string
  }>
}

export interface SubmissionResponse {
  message: string
  submission_id: string
  project_name: string
  status: string
  recommendations: Recommendation[]
  summary: {
    total_recommendations: number
    critical_items: number
    high_priority_items: number
  }
}

export interface ReviewResponse {
  message: string
  review_id: string
  overall_status: string
  overall_score: number
}

export interface ReportResponse {
  message: string
  review_id: string
  report_url: string
}

class APIClient {
  private baseURL: string

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseURL}${endpoint}`
    
    const defaultHeaders = {
      'Content-Type': 'application/json',
    }

    const config: RequestInit = {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    }

    try {
      const response = await fetch(url, config)
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(
          errorData.error || `HTTP error! status: ${response.status}`
        )
      }

      return await response.json()
    } catch (error) {
      console.error('API request failed:', error)
      throw error
    }
  }

  // Submit a new AI solution for review
  async submitReview(data: AIReviewSubmission): Promise<SubmissionResponse> {
    return this.request<SubmissionResponse>('/submit-review', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  }

  // Process/start review for a submission
  async processReview(submissionId: string): Promise<ReviewResponse> {
    return this.request<ReviewResponse>('/process-review', {
      method: 'POST',
      body: JSON.stringify({ submission_id: submissionId }),
    })
  }

  // Generate report for a completed review
  async generateReport(reviewId: string): Promise<ReportResponse> {
    return this.request<ReportResponse>('/generate-report', {
      method: 'POST',
      body: JSON.stringify({ review_id: reviewId }),
    })
  }

  // Get review status (if you add a GET endpoint later)
  async getReviewStatus(submissionId: string): Promise<any> {
    return this.request(`/review-status/${submissionId}`, {
      method: 'GET',
    })
  }

  // List all submissions (if you add a GET endpoint later)
  async listSubmissions(userEmail?: string): Promise<any[]> {
    const query = userEmail ? `?email=${encodeURIComponent(userEmail)}` : ''
    return this.request(`/submissions${query}`, {
      method: 'GET',
    })
  }
}

// Export singleton instance
export const apiClient = new APIClient()

// Export class for custom instances
export default APIClient
