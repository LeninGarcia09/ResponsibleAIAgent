'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { apiClient, AIReviewSubmission, SubmissionResponse } from '@/lib/api'
import styles from './submit.module.css'

export default function SubmitPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<SubmissionResponse | null>(null)
  const [formData, setFormData] = useState<Partial<AIReviewSubmission>>({
    project_name: '',
    project_description: '',
    deployment_stage: 'Development',
  })

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleMultiSelectChange = (name: string, value: string) => {
    setFormData(prev => {
      const currentArray = (prev[name as keyof AIReviewSubmission] as string[]) || []
      if (currentArray.includes(value)) {
        return {
          ...prev,
          [name]: currentArray.filter(item => item !== value),
        }
      } else {
        return {
          ...prev,
          [name]: [...currentArray, value],
        }
      }
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setResult(null)

    try {
      // Validate required fields
      if (!formData.project_name) {
        throw new Error('Please provide a project name')
      }

      const response = await apiClient.submitReview(formData as AIReviewSubmission)
      setResult(response)
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Submission failed')
      console.error('Submission error:', err)
    } finally {
      setLoading(false)
    }
  }

  const getPriorityClass = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'critical':
        return styles.priorityCritical
      case 'high':
        return styles.priorityHigh
      case 'medium':
        return styles.priorityMedium
      default:
        return styles.priorityLow
    }
  }

  return (
    <div className={styles.container}>
      <header className={styles.header}>
        <button onClick={() => router.push('/')} className={styles.backButton}>
          ← Back to Home
        </button>
        <h1 className={styles.title}>AI Solution Review</h1>
        <p className={styles.subtitle}>
          Get instant Responsible AI recommendations and tool suggestions
        </p>
      </header>

      {!result ? (
        <form onSubmit={handleSubmit} className={styles.form}>
          {error && <div className={styles.error}>{error}</div>}

          <section className={styles.section}>
            <h2 className={styles.sectionTitle}>Project Information</h2>
            
            <div className={styles.formGroup}>
              <label className={styles.label}>
                Project Name <span className={styles.required}>*</span>
              </label>
              <input
                type="text"
                name="project_name"
                value={formData.project_name}
                onChange={(e) => setFormData(prev => ({ ...prev, project_name: e.target.value }))}
                className={styles.input}
                required
                placeholder="e.g., Customer Service AI Chatbot"
              />
            </div>

            <div className={styles.formGroup}>
              <label className={styles.label}>
                Project Description (Optional)
              </label>
              <textarea
                name="project_description"
                value={formData.project_description}
                onChange={(e) => setFormData(prev => ({ ...prev, project_description: e.target.value }))}
                className={styles.textarea}
                rows={4}
                placeholder="Briefly describe your AI solution and its purpose..."
              />
            </div>

            <div className={styles.formGroup}>
              <label className={styles.label}>Deployment Stage</label>
              <select
                name="deployment_stage"
                value={formData.deployment_stage}
                onChange={(e) => setFormData(prev => ({ ...prev, deployment_stage: e.target.value }))}
                className={styles.select}
              >
                <option value="Planning">Planning</option>
                <option value="Development">Development</option>
                <option value="Testing">Testing</option>
                <option value="Staging">Staging</option>
                <option value="Production">Production</option>
              </select>
            </div>
          </section>

          <div className={styles.submitSection}>
            <button
              type="submit"
              disabled={loading}
              className={styles.submitButton}
            >
              {loading ? 'Analyzing...' : 'Get Recommendations'}
            </button>
            <button
              type="button"
              onClick={() => router.push('/')}
              className={styles.cancelButton}
            >
              Cancel
            </button>
          </div>
        </form>
      ) : (
        <div className={styles.results}>
          <div className={styles.resultHeader}>
            <h2>Recommendations for: {result.project_name}</h2>
            <div className={styles.summary}>
              <span className={styles.summaryItem}>
                Total: <strong>{result.summary.total_recommendations}</strong>
              </span>
              <span className={styles.summaryItem}>
                Critical: <strong className={styles.criticalCount}>{result.summary.critical_items}</strong>
              </span>
              <span className={styles.summaryItem}>
                High Priority: <strong className={styles.highCount}>{result.summary.high_priority_items}</strong>
              </span>
            </div>
            <p className={styles.submissionId}>Submission ID: {result.submission_id}</p>
          </div>

          <div className={styles.recommendations}>
            {result.recommendations.map((rec, index) => (
              <div key={index} className={styles.recommendationCard}>
                <div className={styles.cardHeader}>
                  <h3 className={styles.principle}>{rec.principle}</h3>
                  <span className={`${styles.priorityBadge} ${getPriorityClass(rec.priority)}`}>
                    {rec.priority}
                  </span>
                </div>

                <div className={styles.cardBody}>
                  <h4 className={styles.subsectionTitle}>Recommendations:</h4>
                  <ul className={styles.recommendationList}>
                    {rec.recommendations.map((item, idx) => (
                      <li key={idx}>{item}</li>
                    ))}
                  </ul>

                  {rec.tools && rec.tools.length > 0 && (
                    <>
                      <h4 className={styles.subsectionTitle}>Recommended Tools:</h4>
                      <div className={styles.toolsList}>
                        {rec.tools.map((tool, idx) => (
                          <div key={idx} className={styles.toolCard}>
                            <a 
                              href={tool.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className={styles.toolName}
                            >
                              {tool.name} ↗
                            </a>
                            <p className={styles.toolDescription}>{tool.description}</p>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className={styles.actionButtons}>
            <button
              onClick={() => {
                setResult(null)
                setFormData({ project_name: '', project_description: '', deployment_stage: 'Development' })
              }}
              className={styles.submitButton}
            >
              Review Another Project
            </button>
            <button
              onClick={() => router.push('/')}
              className={styles.cancelButton}
            >
              Back to Home
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
