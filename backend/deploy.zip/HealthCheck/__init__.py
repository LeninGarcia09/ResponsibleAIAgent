"""
Simple health check endpoint
"""
import azure.functions as func
import json

async def main(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        body=json.dumps({"status": "healthy", "message": "API is working"}),
        status_code=200,
        mimetype="application/json"
    )
